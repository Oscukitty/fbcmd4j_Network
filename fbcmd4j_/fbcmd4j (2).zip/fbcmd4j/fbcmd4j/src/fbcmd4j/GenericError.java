package fbcmd4j;

public class GenericError extends Exception {

	public GenericError() {
		// TODO Auto-generated constructor stub
	}

	public GenericError(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}